## Module #1: Container Manager
Lead: Leo Phan
### Week 1 (11/13 - 11/19)
Work on Container creation
### Week 2 (11/20 - 11/26)
Work on Communication with the client
### Week 3 (11/27 - 12/3)
Work on Parsing the container specification
### Week 4 (12/4 - 12/10)
Work on integration
### Week 5 (12/11 - 12/14)
Work on integration

## Module #2: Shared Memory
Lead: Selman Eris
### Week 1 (11/13 - 11/19)
Read the document and work on level 0
### Week 2 (11/20 - 11/26)
Finish level 0 and level 1
### Week 3 (11/27 - 12/3)
Finish level 2 and level 3
### Week 4 (12/4 - 12/10)
Work on integration
### Week 5 (12/11 - 12/14)
Work on integration

## Module #3: Synchronization
Lead: Jiyan Ayhan
### Week 1 (11/13 - 11/19)
### Week 2 (11/20 - 11/26)
### Week 3 (11/27 - 12/3)
### Week 4 (12/4 - 12/10)
### Week 5 (12/11 - 12/14)

## Module #4: Scheduling
Lead: Hamza Khoja
### Week 1 (11/13 - 11/19)
### Week 2 (11/20 - 11/26)
### Week 3 (11/27 - 12/3)
### Week 4 (12/4 - 12/10)
### Week 5 (12/11 - 12/14)
